document.addEventListener('DOMContentLoaded', () => {
    // Handle sidebar menu item click
    const sidebarItems = document.querySelectorAll('.sidebar-menu-item');
    sidebarItems.forEach(item => {
        item.addEventListener('click', () => {
            sidebarItems.forEach(i => i.classList.remove('active'));
            item.classList.add('active');
            // In a real application, you'd load different content here
            console.log(`Mapsd to: ${item.textContent}`);
        });
    });

    // Handle stats tabs click
    const statsTabs = document.querySelectorAll('.stats-tabs .tab');
    statsTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            statsTabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            const period = tab.dataset.period;
            console.log(`Selected statistics period: ${period}`);
            // In a real application, you'd fetch and display data for the selected period
        });
    });

    // Handle the "Thống kê" (Statistics) button click
    const statsButton = document.querySelector('.stats-button');
    const dateInput = document.querySelector('.date-input');
    statsButton.addEventListener('click', () => {
        const selectedDate = dateInput.value;
        console.log(`Fetching statistics for date: ${selectedDate}`);
        // In a real application, you'd use this date to filter/fetch data
    });

    // Handle the "Báo cáo" (Report) button click
    const reportButton = document.querySelector('.report-button');
    reportButton.addEventListener('click', () => {
        console.log('Generating report...');
        // In a real application, this would trigger report generation logic
        alert('Chức năng báo cáo đang được phát triển!');
    });

    // Simple date input logic (could be replaced with a proper date picker library)
    // For this example, it just logs the value.
});