const services = document.querySelectorAll('.service');
const billList = document.getElementById('bill-list');
const totalDisplay = document.getElementById('total');

let total = 1050000;

services.forEach(service => {
    service.addEventListener('click', () => {
        const name = service.getAttribute('data-name');
        const price = parseInt(service.getAttribute('data-price'));

        if (!service.classList.contains('selected')) {
            service.classList.add('selected');
            const li = document.createElement('li');
            li.innerHTML = `${name} <span class="price">${price.toLocaleString('vi-VN')}</span>`;
            li.setAttribute('data-name', name);
            billList.appendChild(li);
            total += price;
        } else {
            service.classList.remove('selected');
            const item = billList.querySelector(`li[data-name="${name}"]`);
            if (item) {
                item.remove();
                total -= price;
            }
        }

        totalDisplay.textContent = `${total.toLocaleString('vi-VN')}đ`;
    });
});
