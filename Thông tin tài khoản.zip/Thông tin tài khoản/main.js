const editForm = document.getElementById('editInfoForm');
const passwordForm = document.getElementById('changePasswordForm');

document.getElementById('editInfoBtn').addEventListener('click', () => {
  editForm.classList.toggle('hidden');
  passwordForm.classList.add('hidden');
});

document.getElementById('changePasswordBtn').addEventListener('click', () => {
  passwordForm.classList.toggle('hidden');
  editForm.classList.add('hidden');
});

function saveChanges() {
  const name = document.getElementById('editName').value;
  const phone = document.getElementById('editPhone').value;
  const email = document.getElementById('editEmail').value;

  if (!name || !phone || !email) {
    alert("Vui lòng điền đầy đủ thông tin!");
    return;
  }

  alert("Thông tin đã được cập nhật!");
  editForm.classList.add('hidden');
}

function cancelEdit() {
  editForm.classList.add('hidden');
}

function changePassword() {
  const oldPass = document.getElementById('oldPassword').value;
  const newPass = document.getElementById('newPassword').value;
  const confirmPass = document.getElementById('confirmPassword').value;

  if (!oldPass || !newPass || !confirmPass) {
    alert("Vui lòng điền đầy đủ các trường!");
    return;
  }

  if (newPass !== confirmPass) {
    alert("Mật khẩu xác nhận không khớp!");
    return;
  }

  alert("Mật khẩu đã được thay đổi!");
  passwordForm.classList.add('hidden');
}

function cancelPasswordChange() {
  passwordForm.classList.add('hidden');
}
