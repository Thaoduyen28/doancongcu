// Ví dụ thêm sự kiện cho nút Đặt phòng
document.getElementById('bookBtn').addEventListener('click', () => {
  alert('Bạn đã đặt phòng King Room thành công!');
});
