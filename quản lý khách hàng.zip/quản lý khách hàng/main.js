function addCustomer() {
  alert("Thêm khách hàng (demo)");
}

function updateCustomer() {
  alert("Cập nhật khách hàng (demo)");
}

function deleteCustomer() {
  alert("Xóa khách hàng (demo)");
}
