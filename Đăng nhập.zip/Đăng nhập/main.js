document.getElementById('loginForm').addEventListener('submit', function(e) {
  e.preventDefault();

  const phone = document.getElementById('phone').value;
  const password = document.getElementById('password').value;

  if (!phone || !password) {
    alert("Vui lòng nhập đầy đủ thông tin!");
    return;
  }

  // Simulate login success
  alert(`Đăng nhập thành công với số điện thoại: ${phone}`);
});
